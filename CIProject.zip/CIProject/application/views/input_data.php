<!doctype html>
<html>
    <head>
        <title><?php echo $title; ?></title>
        <link rel="stylesheet" href="CIProject/asset/bootstrap/bootstrap.css"/>
</head>
<body>
<form method="POST" action="http://localhost/CIProject/Welcome/luas_s3">
Alas : <input type="text" name="nalas"><br>
Tinggi : <input type="text" name="ntinggi"><br>
<input type="SUBMIT" name="submit" text="hitung">
</form>
    <script src="<?php echo base_url() ?>asset/bootstrap/bootstrap.js"></script>
    <script src="<?php echo base_url() ?>asset/bootstrap/jquery-1.11.0.js"></script>
    </body>
</html>