<?php
/**
 * 
 */
class Mhitung extends CI_MODEL
{
	
	public function luas_s3($alas, $tinggi)
	{
		return($alas*$tinggi)/2;
	}
}